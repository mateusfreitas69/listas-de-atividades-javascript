function calcularDolar() {
  const cotacao = parseFloat(document.getElementById("cotacao1").value);
  const aumentos = [1, 2, 5, 10];
  let resultado = "";

  aumentos.forEach(p => {
    const novoValor = cotacao * (1 + p / 100);
    resultado += `${p}% de aumento: R$ ${novoValor.toFixed(2)}<br>`;
  });

  document.getElementById("resultado1").innerHTML = resultado;
}
