function calcularIngredientes() {
  const pessoas = parseInt(document.getElementById("pessoas2").value);
  const ovos = pessoas * 2;
  const queijo = pessoas * 50;
  
  document.getElementById("resultado2").innerHTML = 
    `Serão necessários:<br>${ovos} ovos<br>${queijo}g de queijo`;
}
