function calcularPedido() {
  const sabores = document.getElementById("sabores4").value;
  const qtdSabores = sabores.split(",").length;
  const qtdRefri = parseInt(document.getElementById("refri4").value);

  const valorPizza = qtdSabores * 12;
  const valorRefri = qtdRefri * 7;
  const total = valorPizza + valorRefri;

  document.getElementById("resultado4").innerHTML =
    `Sabores: ${sabores}<br>` +
    `Valor das pizzas: R$ ${valorPizza.toFixed(2)}<br>` +
    `Valor dos refrigerantes: R$ ${valorRefri.toFixed(2)}<br>` +
    `Total a pagar: R$ ${total.toFixed(2)}`;
}
