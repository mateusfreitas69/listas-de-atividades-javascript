function calcularOperacoes() {
  const a = parseFloat(document.getElementById("n1_3").value);
  const b = parseFloat(document.getElementById("n2_3").value);
  
  const soma = a + b;
  const sub = a - b;
  const mult = a * b;
  const div = b !== 0 ? (a / b).toFixed(2) : "Divisão por zero!";

  document.getElementById("resultado3").innerHTML =
    `Soma: ${soma}<br>Subtração: ${sub}<br>` +
    `Multiplicação: ${mult}<br>Divisão: ${div}`;
}
