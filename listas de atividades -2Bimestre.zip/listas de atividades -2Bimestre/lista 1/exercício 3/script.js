function reajustarSaldo() {
  const saldo = parseFloat(document.getElementById("saldo3").value);
  const novoSaldo = saldo * 1.01;
  document.getElementById("resultado3").innerText = "Novo saldo: R$ " + novoSaldo.toFixed(2);
}
