function calcularValorFinal() {
  const preco = parseFloat(document.getElementById("precoQuilo2").value);
  const quantidade = parseFloat(document.getElementById("quantidade2").value);
  const total = preco * quantidade;
  document.getElementById("resultado2").innerText = "Total a pagar: R$ " + total.toFixed(2);
}
