function calcularMedias() {
  const a = parseFloat(document.getElementById("num4a").value);
  const b = parseFloat(document.getElementById("num4b").value);
  const c = parseFloat(document.getElementById("num4c").value);

  const mediaArit = (a + b + c) / 3;
  const mediaPond = (a*3 + b*2 + c*5) / (3+2+5);
  const soma = mediaArit + mediaPond;
  const mediaDasMedias = soma / 2;

  document.getElementById("resultado4").innerHTML =
    `Média Aritmética: ${mediaArit.toFixed(2)}<br>` +
    `Média Ponderada: ${mediaPond.toFixed(2)}<br>` +
    `Soma das médias: ${soma.toFixed(2)}<br>` +
    `Média das médias: ${mediaDasMedias.toFixed(2)}`;
}
