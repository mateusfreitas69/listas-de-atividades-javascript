function calcularTroco() {
  const pago = parseFloat(document.getElementById("valorPago1").value);
  const preco = parseFloat(document.getElementById("precoProduto1").value);
  const troco = pago - preco;
  document.getElementById("resultado1").innerText = "Troco: R$ " + troco.toFixed(2);
}
