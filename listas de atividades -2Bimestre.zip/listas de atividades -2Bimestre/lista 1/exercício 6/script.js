function menorValor() {
  const valores = [
    parseFloat(document.getElementById("v1_6").value),
    parseFloat(document.getElementById("v2_6").value),
    parseFloat(document.getElementById("v3_6").value),
    parseFloat(document.getElementById("v4_6").value)
  ];
  const menor = Math.min(...valores);
  document.getElementById("resultado6").innerText = "Menor valor: " + menor;
}
