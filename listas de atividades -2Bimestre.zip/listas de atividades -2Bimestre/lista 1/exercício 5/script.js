function maiorValor() {
  const a = parseFloat(document.getElementById("v1_5").value);
  const b = parseFloat(document.getElementById("v2_5").value);
  const maior = a > b ? a : b;
  document.getElementById("resultado5").innerText = "Maior valor: " + maior;
}
