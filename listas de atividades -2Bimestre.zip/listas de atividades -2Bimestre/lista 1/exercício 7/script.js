function verificarImpar() {
  const num = parseInt(document.getElementById("valor7").value);
  const resultado = (num % 2 !== 0) ? "É ímpar" : "Não é ímpar";
  document.getElementById("resultado7").innerText = resultado;
}
