function calcularMinimos() {
  const salario = parseFloat(document.getElementById("salario").value);
  const minimo = parseFloat(document.getElementById("minimo").value);
  const qtd = salario / minimo;
  document.getElementById("resultado").innerText = 
    `O funcionário ganha ${qtd.toFixed(2)} salários mínimos.`;
}
