function calcularDias() {
  const anos = parseInt(document.getElementById("anos").value);
  const meses = parseInt(document.getElementById("meses").value);
  const dias = parseInt(document.getElementById("dias").value);

  const total = (anos * 365) + (meses * 30) + dias;
  document.getElementById("resultado").innerText = `Total de dias vividos: ${total}`;
}
