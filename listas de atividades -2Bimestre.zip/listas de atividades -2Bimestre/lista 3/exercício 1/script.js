function calcularArea() {
  const largura = parseFloat(document.getElementById("largura").value);
  const comprimento = parseFloat(document.getElementById("comprimento").value);
  const area = largura * comprimento;
  document.getElementById("resultado").innerText = `Área do terreno: ${area} m²`;
}
