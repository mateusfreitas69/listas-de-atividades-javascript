function calcularTroco() {
  const produto = parseFloat(document.getElementById("produto").value);
  const pago = parseFloat(document.getElementById("pago").value);
  const troco = pago - produto;

  if (troco < 0) {
    document.getElementById("resultado").innerText = "Pagamento insuficiente.";
  } else {
    document.getElementById("resultado").innerText = `Troco: R$ ${troco.toFixed(2)}`;
  }
}
