function calcularLucro() {
  const paes = parseInt(document.getElementById("paes").value);
  const broas = parseInt(document.getElementById("broas").value);
  const total = paes * 0.12 + broas * 1.50;
  const poupanca = total * 0.10;

  document.getElementById("resultado").innerText = 
    `Total: R$ ${total.toFixed(2)} | Poupança: R$ ${poupanca.toFixed(2)}`;
}
