function converter() {
  const horas = parseInt(document.getElementById("horas").value);
  const minutos = parseInt(document.getElementById("minutos").value);
  const segundos = parseInt(document.getElementById("segundos").value);

  const total = (horas * 3600) + (minutos * 60) + segundos;
  document.getElementById("resultado").innerText = `Total: ${total} segundos`;
}
