function calcularFerraduras() {
  const cavalos = parseInt(document.getElementById("cavalos").value);
  const ferraduras = cavalos * 4;
  document.getElementById("resultado").innerText = `Você precisa de ${ferraduras} ferraduras.`;
}
