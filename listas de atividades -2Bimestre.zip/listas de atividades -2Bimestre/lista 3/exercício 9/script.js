function calcularLitros() {
  const tempo = parseFloat(document.getElementById("tempo").value);
  const velocidade = parseFloat(document.getElementById("velocidade").value);
  const distancia = tempo * velocidade;
  const litros = distancia / 12;

  document.getElementById("resultado").innerText =
    `Distância: ${distancia} km | Litros usados: ${litros.toFixed(2)} L`;
}
