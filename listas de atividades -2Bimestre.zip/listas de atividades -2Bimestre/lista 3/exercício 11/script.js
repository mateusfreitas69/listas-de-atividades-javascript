function calcular() {
  const numero = parseFloat(document.getElementById("numero").value);
  const dobro = numero * 2;
  const terca = numero / 3;

  document.getElementById("resultado").innerText =
    `Dobro: ${dobro} | Terça parte: ${terca.toFixed(2)}`;
}
