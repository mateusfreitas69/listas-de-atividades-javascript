function calcularTinta() {
  const area = parseFloat(document.getElementById("area").value);
  const litros = area / 3;
  const latas = Math.ceil(litros / 18);
  const preco = latas * 80;
  document.getElementById("resultado").innerText =
    `Latas: ${latas} - Total: R$ ${preco.toFixed(2)}`;
}
