function aplicarDesconto() {
  const preco = parseFloat(document.getElementById("preco").value);
  const desconto = parseFloat(document.getElementById("desconto").value);

  const valorFinal = preco - (preco * desconto / 100);
  document.getElementById("resultado").innerText = 
    `Valor com desconto: R$ ${valorFinal.toFixed(2)}`;
}
