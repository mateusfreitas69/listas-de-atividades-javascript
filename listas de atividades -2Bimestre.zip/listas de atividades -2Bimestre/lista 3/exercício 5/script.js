function reajustar() {
  const salario = parseFloat(document.getElementById("salario").value);
  const percentual = parseFloat(document.getElementById("percentual").value);
  const novo = salario + (salario * percentual / 100);
  document.getElementById("resultado").innerText = `Novo salário: R$ ${novo.toFixed(2)}`;
}
