function mostrarNumeros() {
  const numero = parseInt(document.getElementById("numero").value);
  const antecessor = numero - 1;
  const sucessor = numero + 1;
  document.getElementById("resultado").innerText =
    `Antecessor: ${antecessor}, Sucessor: ${sucessor}`;
}
